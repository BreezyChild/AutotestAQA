from __future__ import annotations

import json
import logging

import allure
import httpx

logger = logging.getLogger("api.client")


class ApiClient:
    """Thin wrapper over httpx.Client.

    Responsibilities kept in one place so tests stay focused on business logic:
    - base URL and default JSON headers;
    - request/response logging and Allure attachments;
    - connection-level retries (httpx transport retries connect errors only);
    - optional status assertion via `expected_status`.
    """

    def __init__(self, base_url: str, timeout: float = 15.0) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            transport=httpx.HTTPTransport(retries=2),
            headers={"Content-Type": "application/json", "Accept": "application/json"},
        )

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        method: str,
        url: str,
        *,
        expected_status: int | None = None,
        **kwargs,
    ) -> httpx.Response:
        with allure.step(f"{method} {url}"):
            response = self._client.request(method, url, **kwargs)
            self._attach(response)
            logger.info("%s %s -> %s", method, url, response.status_code)
            if expected_status is not None:
                assert response.status_code == expected_status, (
                    f"{method} {url}: expected HTTP {expected_status}, "
                    f"got {response.status_code}. Body: {response.text[:500]}"
                )
            return response

    def get(self, url: str, **kwargs) -> httpx.Response:
        return self.request("GET", url, **kwargs)

    def post(self, url: str, **kwargs) -> httpx.Response:
        return self.request("POST", url, **kwargs)

    def put(self, url: str, **kwargs) -> httpx.Response:
        return self.request("PUT", url, **kwargs)

    def patch(self, url: str, **kwargs) -> httpx.Response:
        return self.request("PATCH", url, **kwargs)

    def delete(self, url: str, **kwargs) -> httpx.Response:
        return self.request("DELETE", url, **kwargs)

    @staticmethod
    def _attach(response: httpx.Response) -> None:
        request = response.request
        request_body = request.content.decode(errors="replace") if request.content else ""
        allure.attach(
            f"{request.method} {request.url}\n\n{request_body}",
            name="request",
            attachment_type=allure.attachment_type.TEXT,
        )
        try:
            body = json.dumps(response.json(), indent=2, ensure_ascii=False)
        except ValueError:
            body = response.text
        allure.attach(
            f"HTTP {response.status_code}\n\n{body}",
            name="response",
            attachment_type=allure.attachment_type.TEXT,
        )
