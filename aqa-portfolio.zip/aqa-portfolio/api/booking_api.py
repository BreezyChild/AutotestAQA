from __future__ import annotations

import httpx

from api.client import ApiClient
from api.models import AuthToken, Booking, BookingCreated


class BookingApi:
    """Service object for the Restful Booker API.

    Methods return either validated pydantic models (happy path helpers)
    or a raw `httpx.Response` when the test needs to inspect an error.
    """

    def __init__(self, client: ApiClient) -> None:
        self._client = client

    def create_token(self, username: str, password: str) -> httpx.Response:
        return self._client.post(
            "/auth",
            json={"username": username, "password": password},
            expected_status=200,
        )

    def auth_token(self, username: str, password: str) -> str:
        return AuthToken.model_validate(self.create_token(username, password).json()).token

    def create_booking(self, payload: dict) -> BookingCreated:
        response = self._client.post("/booking", json=payload, expected_status=200)
        return BookingCreated.model_validate(response.json())

    def get_booking(self, booking_id: int, expected_status: int | None = 200) -> httpx.Response:
        return self._client.get(f"/booking/{booking_id}", expected_status=expected_status)

    def get_booking_model(self, booking_id: int) -> Booking:
        return Booking.model_validate(self.get_booking(booking_id).json())

    def get_booking_ids(self, **filters) -> list[int]:
        response = self._client.get("/booking", params=filters, expected_status=200)
        return [item["bookingid"] for item in response.json()]

    def update_booking(
        self,
        booking_id: int,
        payload: dict,
        token: str | None,
        expected_status: int | None = 200,
    ) -> httpx.Response:
        return self._client.put(
            f"/booking/{booking_id}",
            json=payload,
            cookies=self._auth_cookies(token),
            expected_status=expected_status,
        )

    def partial_update_booking(
        self,
        booking_id: int,
        payload: dict,
        token: str | None,
        expected_status: int | None = 200,
    ) -> httpx.Response:
        return self._client.patch(
            f"/booking/{booking_id}",
            json=payload,
            cookies=self._auth_cookies(token),
            expected_status=expected_status,
        )

    def delete_booking(
        self,
        booking_id: int,
        token: str | None,
        expected_status: int | None = 201,
    ) -> httpx.Response:
        # Restful Booker quirk: a successful DELETE responds with 201 Created.
        return self._client.delete(
            f"/booking/{booking_id}",
            cookies=self._auth_cookies(token),
            expected_status=expected_status,
        )

    @staticmethod
    def _auth_cookies(token: str | None) -> dict:
        return {"token": token} if token else {}
