from datetime import date

from pydantic import BaseModel, ConfigDict


class _StrictModel(BaseModel):
    """`extra="forbid"` turns every model into a contract check:
    an unexpected field in the response fails the test instead of
    silently passing through."""

    model_config = ConfigDict(extra="forbid")


class BookingDates(_StrictModel):
    checkin: date
    checkout: date


class Booking(_StrictModel):
    firstname: str
    lastname: str
    totalprice: int
    depositpaid: bool
    bookingdates: BookingDates
    additionalneeds: str | None = None


class BookingCreated(_StrictModel):
    bookingid: int
    booking: Booking


class AuthToken(_StrictModel):
    token: str
