from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Project configuration.

    Every value can be overridden through environment variables or a local
    `.env` file, so the same test code runs against any environment.
    """

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    api_base_url: str = "https://restful-booker.herokuapp.com"
    api_username: str = "admin"
    api_password: str = "password123"

    ui_base_url: str = "https://www.saucedemo.com"
    ui_username: str = "standard_user"
    ui_password: str = "secret_sauce"


settings = Settings()
