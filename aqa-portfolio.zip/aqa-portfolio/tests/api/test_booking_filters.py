import allure
import pytest


@allure.feature("Booking API")
@allure.story("Search filters")
@pytest.mark.regression
class TestBookingFilters:
    def test_filter_by_full_name_returns_created_booking(self, booking_api, create_booking):
        created = create_booking(firstname="Zorislav", lastname="Filtertestov")

        found_ids = booking_api.get_booking_ids(
            firstname="Zorislav", lastname="Filtertestov"
        )

        assert created.bookingid in found_ids

    def test_filter_by_wrong_name_excludes_booking(self, booking_api, create_booking):
        created = create_booking(firstname="Zorislav", lastname="Filtertestov")

        found_ids = booking_api.get_booking_ids(firstname="Definitely", lastname="Missing")

        assert created.bookingid not in found_ids
