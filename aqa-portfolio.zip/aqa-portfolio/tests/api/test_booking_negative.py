import allure
import pytest


@allure.feature("Booking API")
@allure.story("Negative scenarios")
@pytest.mark.negative
class TestBookingNegative:
    def test_update_without_token_is_forbidden(self, booking_api, create_booking):
        created = create_booking()

        booking_api.partial_update_booking(
            created.bookingid, {"firstname": "Hacker"}, token=None, expected_status=403
        )

        untouched = booking_api.get_booking_model(created.bookingid)
        assert untouched.firstname == created.booking.firstname

    def test_delete_without_token_is_forbidden(self, booking_api, create_booking):
        created = create_booking()

        booking_api.delete_booking(created.bookingid, token=None, expected_status=403)

        booking_api.get_booking(created.bookingid, expected_status=200)

    def test_get_missing_booking_returns_404(self, booking_api):
        booking_api.get_booking(999_999_999, expected_status=404)

    def test_auth_with_wrong_credentials_returns_reason(self, booking_api):
        # Documented quirk of the demo API: bad credentials still respond
        # with HTTP 200 and a {"reason": "Bad credentials"} body.
        # A production service would be expected to return 401.
        response = booking_api.create_token("admin", "wrong-password")
        assert response.json() == {"reason": "Bad credentials"}

    def test_create_booking_with_broken_payload_fails(self, api_client):
        # The demo API answers 500 to malformed payloads; a real service
        # should validate input and respond 400. The test pins the current
        # behaviour so any change gets noticed.
        api_client.post("/booking", json={"firstname": "only-one-field"}, expected_status=500)
