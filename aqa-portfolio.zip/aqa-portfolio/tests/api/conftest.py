from typing import Callable

import pytest

from api.booking_api import BookingApi
from api.client import ApiClient
from api.models import BookingCreated
from config import settings
from utils.data_factory import booking_payload


@pytest.fixture(scope="session")
def api_client():
    client = ApiClient(settings.api_base_url)
    yield client
    client.close()


@pytest.fixture(scope="session")
def booking_api(api_client) -> BookingApi:
    return BookingApi(api_client)


@pytest.fixture(scope="session")
def auth_token(booking_api) -> str:
    return booking_api.auth_token(settings.api_username, settings.api_password)


@pytest.fixture
def create_booking(booking_api, auth_token) -> Callable[..., BookingCreated]:
    """Factory fixture: creates bookings on demand and cleans them up
    after the test, so runs never leak data into the shared environment."""
    created_ids: list[int] = []

    def _create(**overrides) -> BookingCreated:
        created = booking_api.create_booking(booking_payload(**overrides))
        created_ids.append(created.bookingid)
        return created

    yield _create

    for booking_id in created_ids:
        # expected_status=None: the booking may have been removed by the test itself.
        booking_api.delete_booking(booking_id, auth_token, expected_status=None)
