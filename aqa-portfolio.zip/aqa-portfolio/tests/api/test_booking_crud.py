import allure
import pytest

from api.models import Booking


@allure.feature("Booking API")
@allure.story("CRUD")
class TestBookingCrud:
    @pytest.mark.smoke
    def test_full_booking_lifecycle(self, booking_api, auth_token, create_booking):
        with allure.step("Create a booking"):
            created = create_booking()

        with allure.step("Read it back and validate the response contract"):
            booking = Booking.model_validate(booking_api.get_booking(created.bookingid).json())
            assert booking == created.booking

        with allure.step("Change the guest name via PATCH"):
            booking_api.partial_update_booking(
                created.bookingid, {"firstname": "Updated"}, auth_token
            )
            updated = booking_api.get_booking_model(created.bookingid)
            assert updated.firstname == "Updated"
            assert updated.bookingdates == created.booking.bookingdates, (
                "PATCH must not touch fields that were not sent"
            )

        with allure.step("Delete the booking and make sure it is gone"):
            booking_api.delete_booking(created.bookingid, auth_token)
            booking_api.get_booking(created.bookingid, expected_status=404)

    @pytest.mark.regression
    def test_put_replaces_booking_completely(self, booking_api, auth_token, create_booking):
        created = create_booking()
        new_payload = {
            "firstname": "Replaced",
            "lastname": "Entirely",
            "totalprice": 1,
            "depositpaid": True,
            "bookingdates": {"checkin": "2026-08-01", "checkout": "2026-08-05"},
            "additionalneeds": "late checkout",
        }

        booking_api.update_booking(created.bookingid, new_payload, auth_token)

        stored = booking_api.get_booking_model(created.bookingid)
        assert stored == Booking.model_validate(new_payload)

    @pytest.mark.regression
    @pytest.mark.parametrize(
        "depositpaid", [True, False], ids=["deposit-paid", "deposit-unpaid"]
    )
    def test_create_booking_keeps_deposit_flag(self, create_booking, depositpaid):
        created = create_booking(depositpaid=depositpaid)
        assert created.booking.depositpaid is depositpaid
