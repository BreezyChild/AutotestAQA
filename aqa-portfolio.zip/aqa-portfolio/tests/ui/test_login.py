import allure
import pytest
from playwright.sync_api import expect

from config import settings


@allure.feature("UI: Sauce Demo")
@allure.story("Login")
class TestLogin:
    @pytest.mark.smoke
    def test_successful_login_opens_inventory(self, login_page):
        inventory = login_page.login(settings.ui_username, settings.ui_password)

        expect(inventory.items.first).to_be_visible()
        assert inventory.page.url.endswith("/inventory.html")

    @pytest.mark.negative
    @pytest.mark.parametrize(
        ("username", "password", "error"),
        [
            ("locked_out_user", "secret_sauce", "Sorry, this user has been locked out"),
            ("standard_user", "wrong_password", "Username and password do not match"),
            ("", "", "Username is required"),
        ],
        ids=["locked-out-user", "wrong-password", "empty-form"],
    )
    def test_login_error_messages(self, login_page, username, password, error):
        login_page.login(username, password)
        login_page.expect_error(error)
