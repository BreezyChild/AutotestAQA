import allure
import pytest


@allure.feature("UI: Sauce Demo")
@allure.story("Inventory")
@pytest.mark.regression
class TestInventory:
    def test_sort_by_price_low_to_high(self, inventory_page):
        inventory_page.sort_by("lohi")

        prices = inventory_page.item_prices()
        assert prices == sorted(prices)

    def test_sort_by_price_high_to_low(self, inventory_page):
        inventory_page.sort_by("hilo")

        prices = inventory_page.item_prices()
        assert prices == sorted(prices, reverse=True)
