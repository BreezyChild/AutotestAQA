import pytest

from config import settings
from ui.pages.inventory_page import InventoryPage
from ui.pages.login_page import LoginPage


@pytest.fixture(scope="session")
def base_url() -> str:
    # Consumed by pytest-playwright's `page` fixture, so page.goto("/") works.
    return settings.ui_base_url


@pytest.fixture(autouse=True)
def block_images(page):
    """Abort image requests: less traffic means faster and more stable runs
    on slow CI workers. Also demonstrates network interception in Playwright."""
    page.route("**/*.{png,jpg,jpeg}", lambda route: route.abort())


@pytest.fixture
def login_page(page) -> LoginPage:
    return LoginPage(page).open()


@pytest.fixture
def inventory_page(login_page) -> InventoryPage:
    return login_page.login(settings.ui_username, settings.ui_password)
