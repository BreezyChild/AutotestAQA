import allure
import pytest
from playwright.sync_api import expect

BACKPACK = "sauce-labs-backpack"
BIKE_LIGHT = "sauce-labs-bike-light"


@allure.feature("UI: Sauce Demo")
@allure.story("Cart")
class TestCart:
    @pytest.mark.smoke
    def test_cart_badge_reflects_added_and_removed_items(self, inventory_page):
        inventory_page.add_to_cart(BACKPACK)
        inventory_page.add_to_cart(BIKE_LIGHT)
        expect(inventory_page.cart_badge).to_have_text("2")

        inventory_page.remove_from_cart(BIKE_LIGHT)
        expect(inventory_page.cart_badge).to_have_text("1")

    @pytest.mark.regression
    def test_cart_keeps_selected_product(self, inventory_page):
        inventory_page.add_to_cart(BACKPACK)

        cart = inventory_page.open_cart()

        assert cart.item_names() == ["Sauce Labs Backpack"]
