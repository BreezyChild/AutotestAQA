import allure
import pytest
from playwright.sync_api import expect

BACKPACK = "sauce-labs-backpack"
ONESIE = "sauce-labs-onesie"


@allure.feature("UI: Sauce Demo")
@allure.story("Checkout")
@pytest.mark.regression
class TestCheckout:
    def test_checkout_happy_path(self, inventory_page):
        with allure.step("Add two products to the cart"):
            inventory_page.add_to_cart(BACKPACK)
            inventory_page.add_to_cart(ONESIE)

        with allure.step("Go through the checkout form"):
            checkout = inventory_page.open_cart().start_checkout()
            checkout.fill_customer_info("Rodion", "QA", "660000")

        with allure.step("Item total on the overview equals the sum of item prices"):
            assert checkout.item_total() == pytest.approx(sum(checkout.listed_prices()))

        with allure.step("Finish the order and check the confirmation"):
            checkout.finish()
            expect(checkout.complete_header).to_have_text("Thank you for your order!")
