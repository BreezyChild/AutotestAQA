from playwright.sync_api import Page

from ui.pages.base_page import BasePage
from ui.pages.cart_page import CartPage


class InventoryPage(BasePage):
    path = "/inventory.html"

    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.items = page.locator(".inventory_item")
        self.item_prices_locator = page.locator(".inventory_item_price")
        self.cart_badge = page.locator(".shopping_cart_badge")
        self.cart_link = page.locator(".shopping_cart_link")
        self.sort_select = page.locator('[data-test="product-sort-container"]')

    def add_to_cart(self, product_slug: str) -> None:
        self.page.locator(f'[data-test="add-to-cart-{product_slug}"]').click()

    def remove_from_cart(self, product_slug: str) -> None:
        self.page.locator(f'[data-test="remove-{product_slug}"]').click()

    def open_cart(self) -> CartPage:
        self.cart_link.click()
        return CartPage(self.page)

    def sort_by(self, option_value: str) -> None:
        self.sort_select.select_option(option_value)

    def item_prices(self) -> list[float]:
        return [
            float(text.replace("$", ""))
            for text in self.item_prices_locator.all_inner_texts()
        ]
