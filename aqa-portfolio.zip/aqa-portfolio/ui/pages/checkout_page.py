import re

from playwright.sync_api import Page

from ui.pages.base_page import BasePage


class CheckoutPage(BasePage):
    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.first_name_input = page.locator('[data-test="firstName"]')
        self.last_name_input = page.locator('[data-test="lastName"]')
        self.postal_code_input = page.locator('[data-test="postalCode"]')
        self.continue_button = page.locator('[data-test="continue"]')
        self.finish_button = page.locator('[data-test="finish"]')
        self.subtotal_label = page.locator(".summary_subtotal_label")
        self.overview_prices = page.locator(".inventory_item_price")
        self.complete_header = page.locator(".complete-header")

    def fill_customer_info(self, first_name: str, last_name: str, postal_code: str) -> None:
        self.first_name_input.fill(first_name)
        self.last_name_input.fill(last_name)
        self.postal_code_input.fill(postal_code)
        self.continue_button.click()

    def item_total(self) -> float:
        match = re.search(r"\$([\d.]+)", self.subtotal_label.inner_text())
        assert match, "Subtotal label does not contain a price"
        return float(match.group(1))

    def listed_prices(self) -> list[float]:
        return [
            float(text.replace("$", ""))
            for text in self.overview_prices.all_inner_texts()
        ]

    def finish(self) -> None:
        self.finish_button.click()
