from playwright.sync_api import Page

from ui.pages.base_page import BasePage
from ui.pages.checkout_page import CheckoutPage


class CartPage(BasePage):
    path = "/cart.html"

    def __init__(self, page: Page) -> None:
        super().__init__(page)
        self.items = page.locator(".cart_item")
        self.checkout_button = page.locator('[data-test="checkout"]')

    def item_names(self) -> list[str]:
        return self.page.locator(".inventory_item_name").all_inner_texts()

    def start_checkout(self) -> CheckoutPage:
        self.checkout_button.click()
        return CheckoutPage(self.page)
