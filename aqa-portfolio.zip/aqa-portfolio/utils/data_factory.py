from datetime import date, timedelta

from faker import Faker

fake = Faker()


def booking_payload(**overrides) -> dict:
    """Random but valid booking payload.

    Generated data keeps tests independent from each other; any field
    can be pinned through `overrides` when a test needs a known value.
    """
    checkin = date.today() + timedelta(days=fake.random_int(1, 30))
    payload = {
        "firstname": fake.first_name(),
        "lastname": fake.last_name(),
        "totalprice": fake.random_int(50, 2000),
        "depositpaid": fake.boolean(),
        "bookingdates": {
            "checkin": checkin.isoformat(),
            "checkout": (checkin + timedelta(days=fake.random_int(1, 14))).isoformat(),
        },
        "additionalneeds": fake.word(),
    }
    payload.update(overrides)
    return payload
