# AQA Portfolio: API + UI test automation (Python)

Test automation framework built around two public training targets:

- **API**: [Restful Booker](https://restful-booker.herokuapp.com) — auth, CRUD, search filters
- **UI**: [Sauce Demo](https://www.saucedemo.com) — login, inventory, cart, checkout

## Stack

Python 3.12 · pytest · httpx · pydantic v2 · Playwright · Allure · pytest-xdist · GitHub Actions

## Design decisions

**API layer.** `ApiClient` (httpx wrapper) owns logging, Allure attachments,
connection retries and status assertions. `BookingApi` is a service object on
top of it, so tests read as business scenarios, not HTTP plumbing.

**Contract validation.** Responses are parsed into pydantic models with
`extra="forbid"`: an unexpected field in a response fails the test. Schema
drift gets caught without a separate contract-testing tool.

**Test data isolation.** The `create_booking` factory fixture generates random
payloads (Faker) and deletes everything it created during teardown. Tests do
not depend on each other and do not leak data into the shared environment.

**Documented API quirks.** The demo API returns 201 on DELETE, 200 with a
`reason` body on failed auth, and 500 on malformed payloads. The tests pin
this behaviour explicitly, with comments on what a production service should
do instead.

**UI: Page Object + network interception.** Pages expose actions and
locators; navigation methods return the next page object. An autouse fixture
aborts image requests to speed up runs, screenshots and Playwright traces are
kept for failed tests only.

## Running locally

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
playwright install chromium

pytest tests/api -n auto          # API suite, parallel
pytest tests/ui --browser chromium
pytest -m smoke                   # gate set only

# Allure report
pytest --alluredir=allure-results
allure serve allure-results
```

## CI

GitHub Actions runs two jobs on every push and PR, plus a nightly schedule:
API tests in parallel via pytest-xdist, UI tests in headless Chromium with
traces and screenshots on failure. Allure results are uploaded as artifacts.
