# Root conftest: makes the project root importable (`from api...`, `from ui...`)
# without packaging the repo.
